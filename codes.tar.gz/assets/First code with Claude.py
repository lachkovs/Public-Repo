import turtle

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Cool Spiral - Built with Claude!")

t = turtle.Turtle()
t.speed(0)
t.width(2)

colors = ["red", "orange", "yellow", "green", "cyan", "blue", "violet", "magenta"]

for i in range(300):
    t.color(colors[i % len(colors)])
    t.forward(i * 1.5)
    t.left(91)

turtle.done()
    