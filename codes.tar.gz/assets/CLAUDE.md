# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Environment

- **Python**: 3.13 (installed at `AppData\Local\Programs\Python\Python313\`)
- **Installed packages**: `pygame` (2.6.1)
- **IDE**: VS Code and PyCharm

## Running Python scripts

```powershell
python snake_game.py
```

To install a missing package:

```powershell
pip install <package>
```

## Projects in this repo

### snake_game.py
A single-file Pygame snake game. Run directly with `python snake_game.py`. No build step needed.

- Game state is a list of `(x, y)` tuples (`snake[0]` is the head)
- `game_loop()` handles input, movement, collision, and drawing each frame
- `FPS = 10` controls speed; `CELL = 20` controls grid size

### PycharmProjects/100 Days of Code
Python learning exercises from the "100 Days of Code" bootcamp, organized by day. Each subfolder contains a `task.md` describing the exercise and a Python script as the solution.
